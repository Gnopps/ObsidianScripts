---
tags: meeting, held
---
#### Metadata
Project:: [[Dunder Mifflin]]
Date:: [[2022-04-04]]

# Preparation
- [x] Prepare for meeting 📅 2023-04-03 ✅ 2022-04-05

# Agenda & files
- Initial discussion and discovery call

# Attendees
- [[Pam Beesly]]
- [[Michael Scott]]
- [[John Doe]]

# Notes
- They're interested in a good [[CSR]]-solution
- I talked about our various plans on a high level
- Agreed to send more material
- [ ] Send whitepaper
