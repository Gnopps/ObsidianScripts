# General info
- Sent out in [[SampleEmail.eml|this email]]
- Must be implemented latest Q2^[[[John Doe]] in call [[2022-04-04]]]