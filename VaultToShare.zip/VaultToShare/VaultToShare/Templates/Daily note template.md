# Activity
- 

# Learnings
- 

# New cases
- 

# Todos
- 

# Meetings
```dataview
list WITHOUT ID project + " - " + "[["+file.name+"]]"
FROM #meeting
WHERE contains(date(Date), date(this.file.name))
```

# Pomodoros / Tasks done